#include <iostream>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

#define for( i, a, b) for (int q = i ; q < a; q+=b);

typedef long long ll;

int main() {
    int a;
    cin >> a;
    cout << a << " " << __cplusplus;
    for( 1, 44, 4) {cout <<1;}
    cout << "here";
    return 0;
}
