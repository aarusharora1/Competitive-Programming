#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
void solve() {
 cout<<"    ______    ____\n   (      )  |  o |\n  |        |/ ___U|\n@_|_________/\n  |_|_| |_|_|\n";

}
int main() {
 
    solve();
  
  
  

  return 0;
}