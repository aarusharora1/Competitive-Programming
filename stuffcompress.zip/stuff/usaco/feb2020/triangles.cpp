#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
ll n;

void solve() {
  
}
int main() {
  ifstream fin("triangles.in");
    ofstream fout("triangles.out");

    solve();
  
  
  

  return 0;
}