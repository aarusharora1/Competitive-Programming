#include <bits/stdc++.h>
using namespace std;
int main(){

freopen("herding.in","r",stdin);
    freopen("herding.out","w",stdout);
    cout << "1\n2"  << endl;
    return 0;
}