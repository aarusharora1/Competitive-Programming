#include <bits/stdc++.h>
using namespace std;

int main() {
  int t = 0;
  cin >> t;
  while (t--) {
      for (int i = 0 ; i <4 ; i++) {
          string s;
          cin >> s;
          cout << s<<"\n";
      }
  }
  
  

  return 0;
}