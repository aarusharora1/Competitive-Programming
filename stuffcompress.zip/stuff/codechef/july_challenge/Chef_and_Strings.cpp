#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        ll n = 0, q1=0 , q2=0, ans=0;
        cin >> n; cin >> q1;
        fori(1,n,1) {
            cin >> q2; ans+= abs((q2 - q1))-1; q1 = q2;
        }
        cout <<ans <<endl;
    }
  

  return 0;
}