#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;

ll digitsum(ll a) {
    ll ans = 0;
    while (a > 0 ) {
        ans+= (a%10); a/=10;
    }
    return ans;
}

int main() {
  int t;
  cin >> t;
    while (t--) {
        ll n;
        cin >> n;
        ll a=0; ll b=0;
        ll aa , bb;
        for (int i = 0 ; i < n ; i++) {
            cin >> aa >> bb;
            if (digitsum(aa) > digitsum(bb)) {a++;}
            else if (digitsum(aa) < digitsum(bb)) {b++;}
            else {a++;b++;}
        }
        if (a > b) {cout << 0 << " " << a << endl;}
        else if (b > a) {cout << 1 << " " << b << endl;}
        else {cout << 2 << " " << a << endl;}
    }
  

  return 0;
}