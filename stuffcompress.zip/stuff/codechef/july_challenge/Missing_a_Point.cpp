#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;

bool sortx(pair<ll,ll> a , pair<ll,ll> b) {
    return (a.first < b.first);
}
bool sorty(pair<ll,ll> a , pair<ll,ll> b) {
    return (a.second < b.second);
}

int main() {
  int t;
  cin >> t;
    while (t--) {
        ll n = 0; cin >> n ;
        int n2 = 4 * n; n2-=1;
        vector<pair<ll,ll>> a(n2);
        for (int i = 0 ; i<n2 ; i++) {
            cin >> a[i].first >> a[i].second; 
        }
        ll x =0, y=0;
        sort(a.begin(),a.end(),sortx);
        ll last = 1;
        for (int i = 1 ; i <n2 ; i++) {
            if (a[i].first != a[i-1].first) {if (last % 2 == 1) {x = a[i-1].first;break;} else {last = 0;}}
            last++;
        }
        if (a[n2-1].first != a[n2-2].first) {x= a[n2-1].first;}
        sort (a.begin(),a.end(),sorty);
         last = 1;
        for (int i = 1 ; i <n2 ; i++) {
            if (a[i].second != a[i-1].second) {if (last % 2 == 1) {y = a[i-1].second;break;} else {last = 0;}}
            last++;
        }
        if (a[n2-1].second != a[n2-2].second) {y= a[n2-1].second;}

        cout << x << " " << y <<endl;
        

    }
  

  return 0;
}