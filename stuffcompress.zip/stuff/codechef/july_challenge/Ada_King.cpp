#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        int k = 0 ; cin >> k;
        int a = k /8 ; int b = k % 8;
        if (k < 8) {
            cout << "O"; for (int i = 1 ; i < b ; i++) {cout <<".";} for (int i = b; i < 8 ; i++) {cout <<"X";}
            cout << endl;
            for (int j = 0 ; j < 8 ; j++) {
                    cout << "X";
            }
            cout << endl;
            for (int i =  0; i < 6 ; i++) {
                for (int j = 0 ; j < 8 ; j++) {
                    cout << ".";
                }
                cout <<endl;
            }
        }
        else if (k==64) {
            cout << "O.......\n........\n........\n........\n........\n........\n........\n........\n";
        }
        else {
            cout << "O......."<<endl;
            for (int i = 1 ; i < a ; i++) {
                cout <<"........"<<endl;
            }
            for (int i = 0 ; i< b ;i++) {cout << ".";} for (int i = b; i < 8 ; i++) {cout<<"X";}cout<<endl;
            if (a < 7) {cout << "XXXXXXXX"<<endl;}
            for (int i = a+2 ; i< 8 ; i++) {
                cout << "........"<<endl;
            }

        }


    }
  

  return 0;
}