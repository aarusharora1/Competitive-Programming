#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
int main() {
  int t = 0;
  cin >> t;
  while (t--) {
      int n = 0 ; int k =0;
      cin >> n >> k;
      vi lengths;
      vector<char> ss (n);
      int count = 0;
      int total = 0;
      for (int i = 0 ; i <n ; i++) {
          char s;
          cin >>s;
         // cout << s;
          if (s == '0') {
              total++;
              count++;
          }
          else {
              lengths.push_back(count);
              //cout << "Added " << count << "\n";
              count=0;

          }
          ss[i] = s;
      }
        if (k % 2 == 0) {
            if (ss[0] == '0' && ss[n-1] == '0') {
                
            }
            else if (ss[0] == '0') {

            }
            else if (ss[n-1] == '0') {

            }
            else {

            }
        }
        else {

        }



      if (count > 0) {lengths.push_back(count);}
      sort(lengths.begin(),lengths.end());
      reverse(lengths.begin(),lengths.end());
      int ans = total;
      for (int i = 1; i*2 <= k && i <= lengths.size(); i++) {
          ans -= lengths[i-1];
      }
      cout << ans << "\n";
  }
  
  

  return 0;
}