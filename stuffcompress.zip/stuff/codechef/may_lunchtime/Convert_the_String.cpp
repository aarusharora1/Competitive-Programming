#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (long long  q = i ; q < a; q +=b )
#define vi vector<long long>
int main() {
  long long t;
  cin >> t;
    while (t--) {
        int n; cin >> n;
        vi a;
        vi b;
        for (int i = 0 ; i < n ; i++) {
            char c; cin >> c ; a.push_back(int(c));
        }
        fori(0,n,1) {
            char c ;  cin >> c ; b.push_back(int(c));
        }
        int mina=1e4 ; fori(0,n,1) {if (a[q] < mina) {mina=a[q];}}
        int minb=1e4 ; fori(0,n,1) {if (b[q] < minb) {minb=b[q];}}
        int maxa=-1e4 ; fori(0,n,1) {if (a[q] >maxa) {maxa=a[q];}}
        int maxb=-1e4 ; fori(0,n,1) {if (b[q]> maxb) {maxb=b[q];}}
        //cout << " MAXA : " << char(maxa) << " MAXB:  " << char(maxb) << endl;
        if (maxa < maxb) {cout << "-1"  << endl ; continue;}
        if (minb < mina) {cout << "-1" << endl; continue;}
        
    }
  

  return 0;
}