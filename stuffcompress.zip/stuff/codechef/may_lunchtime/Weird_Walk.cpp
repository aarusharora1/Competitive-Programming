#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (long long  q = i ; q < a; q +=b )
#define vi vector<long long>
int main() {
  long long t;
  cin >> t;
    while (t--) {
        vi a , b; a.push_back(0);b.push_back(0);
        long long n , q;
        cin >> n;
        for (long long i = 1 ; i <= n; i++) {
            cin >> q;
            a.push_back(q+a[i-1]);
        }
        for (long long i = 1 ; i <= n; i++) {
            cin >> q;
            b.push_back(q+b[i-1]);
        }q=0;
        for (long long i = 1; i <= n ; i++) {
            if (a[i] == b[i] && a[i-1] == b[i-1]) {
                q += a[i]-a[i-1];
            }
        }
        cout << q << endl;
    }
  

  return 0;
}