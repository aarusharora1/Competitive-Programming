#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int n = 0 ; cin >> n ;
  ll q;
  ll ans = 0;
    for (int i = 0 ; i < n ; i++) {
        ll ma = 0;
        vector<bool> tw (32);
        for (int j = 0 ; j < n ; j ++) {
            cin >> q ; 
                if (q <= 0) {continue;}
            if (q == 1 ) {tw[0]=1; continue;}
            tw[(int)log2(q)] = 1;
        }
        for (int s = 0 ; s < 32 ; s++) {
            if (tw[s]) {ma+=pow(2,s);}
        }
        ans+=ma;
    }
    cout << ans <<endl;
  

  return 0;
}