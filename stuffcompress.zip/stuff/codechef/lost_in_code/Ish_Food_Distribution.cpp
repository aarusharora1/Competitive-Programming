#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int n = 0 ;
  cin >> n;
  vi prex (1e7);
  vi prey (1e7);
  ll q;
  for (int i = 0 ; i < n ; i++) {
      cin >> q;
    prex[q+1]++;
    prex[q] --;
    cin >> q;
    prey[q+1]++;
    prey[q]--;
     cin >> q;
    prex[q+1]++;
    prex[q] --;
    cin >> q;
    prey[q+1]++;
    prey[q]--;
     cin >> q;
    prex[q+1]++;
    prex[q] --;
    cin >> q;
    prey[q+1]++;
    prey[q]--;
  }
  for (int i = 1 ; i < prex.size(); i++) {
      prex[i] += prex[i-1];
      prey[i] += prey[i-1];
  }
  ll m;
  cin >> m;
    for (int i = 0 ; i < m ; i++) {
        char x , y ;
        cin >> x >> y;
        int s ;
        cin >> s;
        if (x == 'x') {cout << prex[s];}
        else {cout << prey[s];}
    }
  

  return 0;
}