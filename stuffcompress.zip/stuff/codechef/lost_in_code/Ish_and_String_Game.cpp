#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <map>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        string a , b;
        cin >> a >> b;
        map<char,bool> q;
        for (int i = 0 ; i < b.size(); i++) {
            q[b.at(i)] = true;
        }
        for (int i = 0 ; i < a.size() ; i++) {
            if (!(q[a.at(i)])) {cout << a[i];}
        }
        cout << endl;
    }
  

  return 0;
}