#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        int n = 0 ; cin >> n;
        vi num (n);
        fori(0,n,1) {cin >> num[q];}
        sort(num.begin(),num.end());
        int ans = 0;
        for (int q = n-3 ; q >=0 ; q-=3) {
            ans+=num[q];
        }
        cout << ans << endl;
    }
  

  return 0;
}