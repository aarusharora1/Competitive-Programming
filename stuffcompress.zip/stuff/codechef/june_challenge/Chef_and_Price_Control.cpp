#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
int main() {
  int t;
  cin >> t;
    while (t--) {
        int n = 0 , k = 0; cin >>  n >> k;
        int ans  = 0, q=0 , ans2 =0 ;
        for (int i = 0 ; i < n ; i++) {
            cin >>  q; ans+=min(q,k); ans2+=q;
        }
        cout << ans2- ans  << endl;
    }
  

  return 0;
}