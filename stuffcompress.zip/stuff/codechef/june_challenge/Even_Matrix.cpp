#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
int main() {
  int t;
  cin >> t;
    while (t--) {
        int n;  cin >> n;
        vector<vector<int>> num;
        for (int i = 0 ; i < n ; i++) {
            vector<int> b;
            for (int pp = 1 ; pp <=  n ; pp++) {
                b.push_back(n*i + pp);
            }
            if (i % 2 == 1) {num.push_back(b);}
            else {reverse(b.begin(),b.end());num.push_back(b);}
        }
        for (int i = 0  ; i < n ; i++) {
            for (int ii = 0 ; ii < n ; ii++) {
                cout << num[i][ii] << " ";
            }
            cout << endl;
        }
    }
  

  return 0;
}