#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
int main() {
  int t;
  cin >> t;
    while (t--) {
        int n = 0 ,q = 0; cin >> n; bool ans = true;
        vi coins ; coins.resize(16);
        for (int i  = 0 ; i < n ; i++) {
            cin >> q; 
            if (q == 5) {coins[q] ++; }
            else if (q== 10) {ans = coins[5]; coins[q]++;coins[5]--;}
            else {
                if (coins[10] >= 1) {
                    coins[10]--; ans = true;
                }
                else if (coins[5] >= 2) {
                    coins[5] -=2; ans = true;
                }
                else {
                    ans = false;
                }
                 coins[q]++;
            }
            if (!ans) {
                int q2 = i+1;
                while (q2 < n) {cin >> q;  q2++;}
                break;
            }    
        }       
        if (ans) {cout << "YES" << endl;}
        else {cout << "NO" << endl;}
    }
  

  return 0;
}