#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
#define ll long long

int main() {
  int t;
  cin >> t;
    while (t--) {
        ll ts = 0 ; cin >> ts;
        if (ts % 2 == 1) {
            cout << ts/2 << endl; continue;
        }
        while (ts % 2 == 0 && ts > 0) {
            ts/=2;
        }
        cout << ts/2 << endl;
    }
  

  return 0;
}