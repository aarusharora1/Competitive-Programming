#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
int main() {
  int t;
  cin >> t;
    while (t--) {
         int n = 0 ;
         string s; int ans=0;
         cin  >> s;
         n = s.size();
         for (int i = 0 ; i < n-1; i++) {
             //cout << s[i];
             if (s[i] == 'x' && s[i+1] == 'y') {
                ans++; i++;
             }
             else if (s[i]=='y' && s[i+1] == 'x') {
                 ans++; i++;
             }
         }
         cout << ans << endl;
    }
  

  return 0;
}