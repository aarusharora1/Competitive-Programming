#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
#define ll long long
int main() {
  int t;
  cin >> t;
    while (t--) {
        vector<ll> a , b;
        ll q;
        for (int i = 0 ; i < 3 ; i++) {
            cin >> q ; a.push_back(q);
        }
        for (int i = 0 ; i < 3 ; i++) {
            cin >> q ; b.push_back(q);
        }
        vector<ll> add , mult, mod, div;
        mod.resize(3); div.resize(3);
        for (int i = 0; i < 3 ; i++) {
            add.push_back(b[i]-a[i]);
            if (a[i] != 0&&b[i]%a[i] == 0  ) {
                mult.push_back(b[i]/a[i]);
            }
            else if (a[i] != 0) {
                mod[i] = (b[i] % a[i]);
                div[i] = (b[i]/a[i]);
                mult.push_back(-10);
            }
            else {
                mult.push_back(-100);
            }
        }
        /*
        int ans=0;
        for (int i = 0 ; i< 3 ; i++) {
            if (a[i]==b[i]) {ans--; continue;}
            for (int i2 = i+1 ; i2 < 3 ; i2 ++) {
                cout << " I:  " << i << "  ADD I :  " << add[i] << " MULT I :: " << mult[i] << endl;
                cout << " I2:  " << i2 << "  ADD I2 :  " << add[i2] << " MULT I2 :: " << mult[i2] << endl;
                if (add[i]==add[i2] || (mult[i] > 0 && mult[i]==mult[i2])) {
                    visited
                    ans--;
                }
                else if (mod[i] == mod[i2] && div[i] == div[i2]) {ans--;}     
                cout << " NEW ANS : " << ans << endl;   
            }
        }
        */
       if (a[0] == b[0] && a[1] == b[1] && a[2] == b[2])  {
            cout << 0 << endl;
        }
        int ans = 0;
        if (a[0] == b[0] || a[1] == b[1] || a[2] == b[2]) { ans--;}
        if (add[0] == add[1] == add[2]) {cout <<     1 << endl;continue;}
        if (add[0] == add[1] || add[0] == add[2] || add[1] == add[2]) {cout << ans+2 << endl;continue;}
        if (mult[0] == mult[1] == mult[2]) {cout << 1 << endl; continue;}
        if (mult[0] == mult[1] || mult[0] == mult[2] || mult[1] == mult[2]) {cout << ans+2 << endl;continue;}
        if (mod[0] == mod[1] == mod[2] && div[0] == div[1] == div[2]) {
            cout << 2 << endl; continue;}
        cout << 3  << endl;
    }
  

  return 0;
}