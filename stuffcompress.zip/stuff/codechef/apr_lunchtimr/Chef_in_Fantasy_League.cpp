#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>

typedef long long ll;



int main() {
    ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int t=0;
    int n=0;
    int s=0;
    int p=0;
    int zoo=0;
    cin >> t;
    while (t--) {
        cin>> n >>s ;
        
        vi de;
        vi of;
        vi players;
        //cout << "before for\n";
        cout.flush();
        fori (0,n,1) {cin >> p;players.push_back(p);}
        //cout << "before 2nd for\n";
        cout.flush();
        fori (0,n,1) {
            cin >> zoo; 
            if (zoo == 0) {de.push_back(players[q]);}
            else {of.push_back(players[q]);}
        
        }
        //cout << "after for\n";
        //cout.flush();
        //cout << "before m1\n";
        //cout.flush();
        int m1; int m2;
        if (de.empty() ) {m1 = 20000;}
        else { m1 = *min_element(de.begin(),de.end());}
        //cout << "before m2\n";
        //cout.flush();
        if (of.empty()) {m2 = 20000;}
        else{ m2 = *min_element(of.begin(),of.end());}
        //cout << "before m1+m2\n";
        //cout.flush();
        if (m1 + m2 + s <= 100) {cout << "yes\n";}
        else {cout <<"no\n";}
    }
    //cout << "FINISHED\n";
    return 0;
}
 
