#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        ll n  = 0 , k = 0 ;
        cin >> n >> k;
        string ans = "";
        for (ll i = 0 ; i < n ; i++) {
            ll a = 0 ; cin >> a;
            if (a% k == 0) {ans+="1";}
            else {ans+="0";}
        }
        cout<<ans<<endl;
    }
  

  return 0;
}