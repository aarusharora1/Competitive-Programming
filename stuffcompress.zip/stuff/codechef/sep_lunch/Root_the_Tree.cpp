#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
int n=1e5;
vector<pair<int,int>> edges;
vi dfss(1e5,1) ;
vector<bool>visited (1e5,false);
int dfs(int a , int b) {
    //cout << " A: " << a << " B: " << b << "\n";
    //cout << " OO ";
    //  for (int i = 0 ; i <= n ; i++) {
    //      cout << dfss[i] << " " ;
    //  }
    if (visited[a] == true) {return dfss[a];}
    visited[a] = true;
    int ans = 1;

    for (int i = 0 ; i < n-1 ; i++) {
     //   cout << "edge" << edges[i].first << " a" << a << "\n";
        if (edges[i].first == a) {
     //       cout << ans << "here\n";
            ans += dfs(edges[i].second,0);
            
      //      cout << ans << "here2\n";
        }
    }
    dfss[a] = ans;
    visited[a] = true;
    return ans;

}


int main() {
  int t = 0;
  cin >> t;
  while (t--) {
       edges.clear();
       
       fill(dfss.begin(),dfss.end(), 1);
       fill(visited.begin(),visited.end(),false);

      cin >> n;
      
      int q1 = 0 , q2 = 0;
      for (int i = 0 ; i <n-1; i++) {
          cin >> q1 >> q2;
          edges.push_back(make_pair(q1,q2));
      }
      for (int i = 0 ; i < n ; i++) {
      dfs(1+i,0);
      }
      int ma = 1;
      for (int i = 0 ; i<=n ; i++) {
          ma = max(ma,dfss[i]);
      }
      cout << n-ma << "\n";
  }
  
  

  return 0;
}