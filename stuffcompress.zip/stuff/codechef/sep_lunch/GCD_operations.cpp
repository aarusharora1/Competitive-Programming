#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
int main() {
  int t = 0;
  cin >> t;
  while (t--) {
      int n  = 0;
      cin >> n;
      vi a(n);
      for (int i = 0 ; i< n ;i++) {cin >> a[i];}
      bool good = true;
      for (int i = 0 ; i < n ; i++) {
     
          if ((i+1) % a[i] == 0) {continue;}
          else {good=false; break;}
      }
      if (good) {cout << "YES\n";}
      else {cout <<"NO\n";}
  }
  
  

  return 0;
}