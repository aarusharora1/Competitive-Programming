#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e5+2;

int main() {
    //cout << "FF";
  int  t= 0;
  cin >> t;
  while (t--) {
      int n = 0;
      cin >> n;
      vi a(n);
      vi freq(20);
      
      for (int i = 0 ; i <n ;i++) {
          cin >> a[i];
          freq[a[i]]++;
      }
      //for (auto a : freq) {cout << a << " ";}cout <<"\n";
      vi frfr (maxc);
      for (int i = 0 ; i < 20 ; i ++) {
          frfr[freq[i]]++;
      }
      //for (auto a : frfr) {cout << a << " ";}cout <<"\n";
       int ans = 0; int ans2 = 0;
       for (int i = 1 ; i < maxc ; i++) {
           if (frfr[i]>ans) {ans2=i;ans=frfr[i];}
       }
      cout << ans2 << "\n";
  }
  
  

  return 0;
}