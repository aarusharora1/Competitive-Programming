#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
int main() {
  int t = 0;
  cin >> t;
  while (t--) {
      int n = 0;
      cin >> n;
      vi fr;
        int num = 0;
        int q = 0 ; //cin >> q;
        for (int i = 0; i < n ; i++) {
            cin >> q;
            if (q == 0) {num++;}
            else {if(num==0){continue;}fr.push_back(num);num=0;}
        }
        sort(fr.begin(),fr.end());
        //cout << fr.size() << "p\n";
        if (fr.size() == 0) {cout << "No\n";continue;}
        if (fr.size() == 1) {
            if (fr[0] % 2 == 0) {cout << "No\n";}
            else {cout << "Yes\n";}
            continue;
        }
        if (fr[fr.size()-2] * 2 > fr[fr.size()-1]) {cout << "No\n";}
        else {
            if (fr[fr.size()-1] % 2 == 0) {cout << "No\n";}
            else {cout << "Yes\n";}
        }
  }
  
  

  return 0;
}