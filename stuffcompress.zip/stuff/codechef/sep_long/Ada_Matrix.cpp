#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
int main() {
  int t = 0;
  cin >> t;
  while (t--) {
      int n = 0 ;
      cin >>n;
      vector<vi> a(n);
    for (int i = 0 ; i< n ; i++) {
        vi w(n);
        for (int q= 0; q< n ; q++) {cin>>w[q];}
        a[i]=w;
    }
    int ans =0;
    vi b(n);
    for (int i = 1 ; i<=n ; i++) {
        if (a[0][i-1] != i) {b[i-1]++;}
    }
    //for (auto i : b) {cout << i << " ";}
    //cout << "P\n";
    for (int i = 2; i < n ; i++) {
        if (b[i] == 1 && b[i-1] == 0) {ans+=2;}
    }
    if (b[1]==1){ans++;}
    cout << ans <<"\n";
  }
  
  

  return 0;
}