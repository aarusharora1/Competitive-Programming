#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
int main() {
  int t = 0;
  cin >> t;
  while (t--) {
      int n =0;
      cin >> n;
      vi a(n);
      int maxx = 1;
      int minn = 10000;
      for (int i = 0 ; i <n ; i++) {cin>>a[i];}
        
        
        vi num(n);
        
        for (int i = 0; i< n ; i++) {
            int m1 = 0;
            for (int q = 0; q < i; q++) {
                if (a[q] > a[i] ) {
                    m1++;num[q]++;num[i]++;
                    for (int p = i+1; p < n ; p++) {
                        if (a[q]>=a[p]){m1++;num[i]++;}
                    }
                }
            }
            for (int q = i; q < n ; q++) {
                if (a[q] < a[i] ) 
                {m1++;num[q]++;num[i]++;
                for (int p = 0; p < i ; p++) {
                        if (a[q]<=a[p]){m1++;num[i]++;}
                    }}
            }
            
        }
        for (int i = 0 ; i < n; i ++) {
            num[i]/=2;
            num[i]++;
        }
        minn = *min_element(num.begin(),num.end());
        minn=min(n,minn);
        maxx = *max_element(num.begin(),num.end());
        maxx=min(n,maxx);
        cout << max(1,minn) << " " << max(1,maxx) << "\n";    
  }
  
  

  return 0;
}