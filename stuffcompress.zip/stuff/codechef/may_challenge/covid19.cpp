#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>

typedef long long ll;
#define vpi vector<pair<ll,ll>>

int t;
int n;
int p;
int main() {
    
    cin >> t;
    while (t--) {
        cin >> n;
        vi x; vi f;
        fori(0,n,1) {cin >> p; x.push_back(p);f.push_back(0);}
        f[0] = 1;
        for (int i  =1 ; i < n ; i ++) {
            if (x[i] - x[i-1]  <= 2) { f[i] = f[i-1];}
            else {f[i] = f[i-1] + 1;}
        }
        vi lengths;
        fori(0,10,1) {
            if(count(f.begin(),f.end(),q) != 0) {lengths.push_back(count(f.begin(),f.end(),q));}
        }
        cout << *min_element(lengths.begin(),lengths.end()) << " " << *max_element(lengths.begin(),lengths.end()) << endl; 

    }
    
    return 0;
}
 
