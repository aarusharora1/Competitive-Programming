#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>

typedef long long ll;
#define vpi vector<pair<ll,ll>>
ll t;
ll n;
ll k;

int main() {
    
    cin >> t;
    while (t--) {
        cin >> n >> k;
        ll q = k/(n-1);
        ll ans = q * n -1;
        ll num = q * (n-1);
        if (k < n) {cout << k << endl ; continue;}
        //cout << "ANS: " << ans << " NUM: " << num << endl; 
        while (num <= k) {
            //cout << "NUM : " << num << " K :  " << k << endl ;
            if (ans % n == 0 ) { ans++; }
            else { ans++; num++;}
        }
        cout << ans-1<< endl;
        

    }
    
    return 0;
}
 
