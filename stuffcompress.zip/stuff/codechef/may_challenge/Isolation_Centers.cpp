#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>

typedef long long ll;
#define vpi vector<pair<ll,ll>>
vector<char> r = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
ll t;
ll n;
ll q;
ll c;
string s;
int main() {
    
    cin >> t;
    while (t--) {
        cin >> n >> q;
        cin >> s;
         
        for (ll i = 0 ; i <  q; i ++) {
            ll ans = 0;
            cin >> c;
            for(int qq = 0; qq < 26 ; qq ++ ) {
                if (count(s.begin(),s.end(),r[qq]) > c) {
                ans += (count(s.begin(),s.end(),r[qq]) - c);}
            } cout << ans << endl;
        }
       
        

    }
    
    return 0;
}
 
