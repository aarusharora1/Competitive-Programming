#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>

typedef long long ll;
#define vpi vector<pair<ll,ll>>
ll t;
ll n;


int main() {
    
    cin >> t;
    while (t--) {
        cin >> n;
        int ans = 0 ;
        vi b ;
        int p = 0;
        while (n > 0 ) {
            if (n  % 10 == 0 ){
                n/= 10;
            }
            else {
                b.push_back((n%10)* pow(10,p));
                
                n/=10;
                ans++;
            }
            p++;
        }
        cout << ans << endl; 
        for( int i = 0 ; i  < ans ; i ++ ) {
            cout << b[i] <<  " " ;
        } cout << endl;
        
       
        

    }
    
    return 0;
}
 
