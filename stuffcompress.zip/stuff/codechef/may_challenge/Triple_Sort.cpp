#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>

typedef long long ll;
#define vpi vector<pair<ll,ll>>
ll t;
ll n;
ll q;
ll c;
string s;
int main() {
    
    cin >> t;
    while (t--) {
        cin >> n >> q;
        
       
        

    }
    
    return 0;
}
 
