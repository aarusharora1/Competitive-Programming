#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
const int maxc = 1e9;
int n = 1e7;
vector<pair<int,int>> edges (n);
vector<bool> visited (n, false);
vector<int> anss (n, 0);
vector<bool> isleaf (n,true);
int dfs(int a) {
    if (visited[a]) {return anss[a];}
    int ans = 1;
   
    for (int i = 0 ; i < n-1 ; i++) {
        if (edges[i].first == a) {isleaf[a]=false;
            ans= max(ans,dfs(edges[i].second));if(isleaf[edges[i].second]) {ans++;}
        }
    }
    if (isleaf[a]) {anss[a] = 1;return 1;}
    anss[a] = ans * 2 + 1;
    return ans * 2 +1;
}   
void solve() {
   cin >>n;
    for (int i = 0 ; i < n-1 ; i++) {
        int q;cin>>q;
        edges[i] = make_pair(q-1,i+1);
    }
    
    cout << (dfs(0)+1)/2 << "\n";
    //for (int i = 0 ; i < n ; i++) {
      //  cout << anss[i] << " ";
    //}cout <<"\n";
} 
    

int main() {
  int t = 0;
  cin >> t;
  while (t--) {
    solve();
  }
  
  

  return 0;
}