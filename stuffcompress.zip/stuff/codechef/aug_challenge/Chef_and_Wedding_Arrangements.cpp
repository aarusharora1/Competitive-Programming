#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        vi count (101);
        int n = 0 ;  cin >> n;
        int k = 0 ; cin >> k ;
        vi a (n);
        for (int i = 0 ; i < n ; i++) {
            cin >> a[i]; 
        }
        int num = 0; int ans =k;
        for (int i = 0 ; i < n ; i++) {
            cout << " A[i]: "<<a[i] << " count" << count[a[i]] << " ans " << ans << "\n";
            if (count[a[i]] != 0) {num++;}
            else {count[a[i]]++;}
            if (num == k) {
                num=0; ans +=k;
                for (int q = 0 ; q < 101 ; q++) {count[q]=0;}
            }

        }
        ans+=num;
        cout << ans << "\n";


    }
  

  return 0;
}