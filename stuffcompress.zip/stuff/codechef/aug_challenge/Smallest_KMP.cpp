#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        string s, p;
        cin >> s; cin >> p;
        string ans;
        vector<int> a (27);
        for (int i = 0 ; i < s.size(); i++) {
            a[s[i]-'a']++;
        }
        //cout << " HERE1\n";
        //for (auto i : a) {cout << i << " ";}
        //cout << "\n";
        for (int i = 0 ; i <p.size();i++) {
          a[p[i]-'a']--;
        }
        //for (auto i : a) {cout << i << " ";}
        //cout << "\n";
        //cout << " P " << int(p[0])-'a' << "\n";
        for (int i = 0 ; i < int(p[0])-'a' ;i++){
          //cout << " HI : " << i << "A: "<< a[i] << " CH" << char(i+'a')<<" \n";
            for (int q = 0 ;q < a[i]; q++) {ans+=char('a'+i);}
        }
        int q = 0;
        while (q < p.size() && p[q] == p[0]) {
          q++;
        }
       // cout << " P styop " << q << " P :  " << p[q] << " \n";
        if (int(p[q]-'a') < int(p[0]-'a')) {
          ans+= p;
          for (int s = 0; s < a[p[0]-'a']; s++) {
            ans+= p[0];
          }
        }
        else {
         // cout << " PP " << a[p[0] -'a'] << "\n";
          for (int s = 0; s < a[p[0]-'a']; s++) {
            ans+= p[0];
          }
          ans+= p;
        }
        
        //cout << " HERE1\n";
        //cout << ans << "\n";
        
        for (int i = int(p[0])-'a' +1 ; i < 27; i++) {
          for (int q = 0; q < a[i] ;q++) {ans+=char(i+'a');}
        }
        cout << ans << "\n";
        
    }
  

  return 0;
}