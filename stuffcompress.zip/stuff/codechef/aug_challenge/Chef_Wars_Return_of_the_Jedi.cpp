#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        int h = 0  , p = 0;
        cin >> h >>p;
        while (h > 0 && p > 0) {
            h-=p;
            p/=2;
        }
        if (h > 0) {cout << 0 << "\n";}
        else {cout << "1\n";}
    }
  

  return 0;
}