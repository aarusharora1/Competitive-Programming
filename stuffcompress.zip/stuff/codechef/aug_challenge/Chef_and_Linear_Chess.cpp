#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        ll n = 0 , k = 0;
        cin >> n >> k;
        vector<ll> num (n);
        ll ans = 1e10;
        for (int i = 0 ; i < n ; i++) {
            cin >> num[i]; if (k % num[i] == 0) {ans = min(ans,k/num[i]);}
        }
        if (ans == 1e10) {cout << -1 << "\n";}
        else {cout << k/ans << "\n";}
    }
  

  return 0;
}