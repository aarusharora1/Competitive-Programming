#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
  int t;
  cin >> t;
    while (t--) {
        int pc = 0 , pr = 0;
        cin >> pc >> pr;
        int c = pc / 9;
        int r = pr / 9;
        if (c > r ) {if (pr%9==0){cout<<"1 "<<r<<"\n";}else{cout << "1 " << r + 1 << "\n";}}
        else if (r > c)  {if(pc%9==0){cout<<"0 " << c<<"\n";}else{cout << "0 " << c + 1 << "\n";}}
        else {cout << "1 " << 1+c << "\n";}
    }
  

  return 0;
}