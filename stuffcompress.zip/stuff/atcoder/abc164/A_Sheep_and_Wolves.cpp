#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>

typedef long long ll;


int t;
int main() {
    
        int s;
        int w;
        cin >> s >> w;
        if (w > s ) {cout << "unsafe" << endl;}
        else {cout << "safe" << endl;}
        
    
    return 0;
}
 
