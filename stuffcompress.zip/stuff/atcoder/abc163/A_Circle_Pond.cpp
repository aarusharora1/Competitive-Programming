
#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;


int main() {
    
    
    double n;
    double mu = 6.28318530717958623200;
    cin >> n;
    double ans = n * mu ;
    cout << ans << "\n";
    
    return 0;
}
 
