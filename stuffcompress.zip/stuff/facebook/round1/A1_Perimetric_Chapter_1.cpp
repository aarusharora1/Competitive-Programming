#include <bits/stdc++.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
    int t;
    cin >> t;
    for (int q = 1 ; q <= t; q++) {
        ll n , k , w;
        cin >> n >> k >>w;
        vector<ll> l(n);
        for (ll i = 0 ; i < k ; i++) { cin >> l[i];}
        ll al, bl , cl ,dl;
        cin >> al >> bl >> cl >>dl;
        vector<ll> h(n);
        for (ll i = 0 ; i < k ; i++) {cin >> h[i];}
        ll ah , bh , ch , dh;
        cin >> ah >> bh >>ch >>dh;
        vector<ll> ans (n);
        ll big1 = h[0];
        ll big2 = 0;
        ans[0] = w * 2 + h[0] * 2;

        for (int i =1 ; i < k ; i++) {
            big2 = i-1;
            big1 = h[i-1];
            while (big2 >= 0 && l[i] - l[big2] < w) {
                big1 = max(big1,h[big2]);big2--;
            }
            big2++;
            
            if (l[big2] + w > l[i]) {
                if (h[big2] < h[i]) {
                    
                    ans[i] = ans[i-1] + h[i] - h[big2] + h[i] - h[big2] ;//(2* (l[i] - l[big2]));
                }
                else {
                    
                    ans[i] = ans[i-1] + 2 * (l[i]- l[big2]);
                }
            }
            else if ( l[big2] +w == l[i]) {ans[i] = ans[i-1] + w + w;}
            else {
                
                ans[i]=ans[i-1]+( w * 2 + h[i] * 2);
            }    
            cout << "I: " << i << " h[i]: " <<  h[i] << " big2: " << big2 << " big1: "<< big1  << " h[big2] " << h[big2] << "\n";
            
        }
     // cout << " ANS : \n";
        //for (auto i :ans) {cout << i << " ";}cout<<"\n";
        for (int i = k ; i < n ; i++) {
             l[i] = (((al*l[i-2]) + (bl * l[i-1]) + cl) % dl) +1;
            h[i] = (((ah*h[i-2]) + (bh * h[i-1]) + ch) % dh) +1;
            big2 = i-1;
            big1 = h[i-1];
            while (big2 >= 0 && l[i] - l[big2] < w) {
                big1 = max(big1,h[big2]);big2--;
            }
            big2++;
            
            if (l[big2] + w > l[i]) {
                if (h[big2] < h[i]) {
                  
                    ans[i] = ans[i-1] + h[i] - h[big2] + h[i] - h[big2] ;//(2* (l[i] - l[big2]));
                }
                else {
               
                    ans[i] = ans[i-1] + 2 * (l[i]- l[big2]);
                }
            }
            else if ( l[big2] +w == l[i]) {ans[i] = ans[i-1] + w + w;}
            else {
          
                ans[i]=ans[i-1]+( w * 2 + h[i] * 2);
            }    
            cout << "I: " << i << " h[i]: " <<  h[i] << " big2: " << big2 << " big1: "<< big1  << " h[big2] " << h[big2] << "\n";
            
        }
            cout << " ANS : \n";
        for (auto i :ans) {cout << i << " ";}cout<<"\n";
        ll am = 1;
        //for (int i = 1; i < n ; i++) {ans[i] += ans[i-1];}
        for (int i = 0 ; i < n ; i++) {
            ll q1 = am % 1000000007;
            ll q2 = ans[i] % 1000000007;
            am = (q1 * q2) % 1000000007;
            }
        cout << "Case #" << q << ": "<< am % 1000000007 << "\n";

    }
  

  return 0;
}