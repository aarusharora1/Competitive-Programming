#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    int t;
    cin >> t;
    for (int q = 1; q <= t ; q++) {
        int n = 0 ; 
        cin >> n; vector<char> s(n);
        int a = 0 , b = 0;
        for (int i = 0 ; i < n ; i++) {
            cin >> s[i]; if (s[i] == 'A') {a++;}
            else {b++;}
        }    
        cout << "Case #" << q << ": ";
        if (a * 2 < b || b * 2 < a) {cout << "N\n";}
        else {cout << "Y\n" ;}
    }
  

  return 0;
}