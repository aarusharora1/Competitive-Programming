#include <bits/stdc++.h>

using namespace std;
#define fori(i, a, b) for (int q = i; q < a; q += b)
#define vi vector<int>
typedef long long ll;
int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
	
		int t;
	cin >> t;
	//cout << " T: " << t << endl;
	for (int q = 1; q <= t; q++){
		int n = 0;
		cin >> n;
		string in, out;
		cin >> in;
		cin >> out;

		cout << "Case #" << q << ": \n";
		for (int i = 0; i < n; i++){
			for (int j = 0; j < n; j++){
				if (i == j){cout << "Y";continue;}
				bool okay = true;
				if (out[i] == 'Y' && in[j] == 'Y'){
					if (i < j){

						for (int k = i + 1; k < j; k++){
							if (in[k] == 'N' || out[k] == 'N'){
								okay = false;
							}
						}
					}
					else{
						for (int k = j + 1; k < i; k++){
							if (in[k] == 'N' || out[k] == 'N'){
								okay = false;
							}
						}
					}
					if (okay){cout << 'Y';}
					else{cout << 'N';}
				}
				else {cout << 'N';}
			}
			cout << endl;
		}

		
	}
	
	return 0;
}