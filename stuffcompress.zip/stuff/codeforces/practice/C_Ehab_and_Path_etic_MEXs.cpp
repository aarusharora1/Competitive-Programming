#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
typedef long long ll;
int main() {
 
        int n = 0 ; cin >> n; int q;
        for (int i = 1 ; i < n ; i++)
        {cin >> q ; cin >> q;}
        for (int i = 0 ; i < n-1; i++) {
            cout << i << endl;
        }
    
  

  return 0;
}