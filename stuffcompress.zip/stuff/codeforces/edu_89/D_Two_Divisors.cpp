#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <stdio.h>
#include <vector>
#include <math.h>
using namespace std;
#define fori(i , a ,b) for (int  q = i ; q < a; q +=b )
#define vi vector<int>
#define ll long long
int main() {
  int t;
  cin >> t;
    while (t--) {
        int n  = 0 ; 
        cin >> n; 
        vector<long long> num;
        vector<ll> one;
        vector<ll> two;
        ll q = 0;
        for (int  i = 0 ; i  < n  ; i++) {
            cin >> q;
            num.push_back(q);
            ll d1  = 0 , d2 = 0;
            for (int m = 0 ; m < sqrt(q) ; m++) {
                if (q % m == 0) 
            }
        }
    }
  

  return 0;
}